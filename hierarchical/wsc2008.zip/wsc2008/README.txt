Web Service Challenge 2008 datasets for Web Service Composition.
Centro de Investigación en Tecnoloxías da Información (CITIUS), 
University of Santiago de Compostela.

Original datasets from the WSC'08
http://cec2008.cs.georgetown.edu/wsc08/. 

